<?php

require_once('Utilities/Functions.php');

Functions::logout();